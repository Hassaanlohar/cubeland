plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.cubeland.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.cubeland.app"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}

// Downloads the two JS libraries into assets once, so the game runs offline.
val fetchLibs by tasks.registering {
    val dir = file("src/main/assets/libs")
    doLast {
        mapOf(
            "three.min.js" to "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js",
            "mp4-muxer.js" to "https://cdn.jsdelivr.net/npm/mp4-muxer@5.1.3/build/mp4-muxer.js"
        ).forEach { (n, u) ->
            val f = File(dir, n)
            if (!f.exists() || f.length() == 0L) { dir.mkdirs(); f.writeBytes(java.net.URL(u).readBytes()) }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchLibs) }
