// Provides the "downloads" host API the game already looks for, backed by Android.
(function(){
  if(!window.AndroidBridge) return;
  function toB64(buf){let s='',b=new Uint8Array(buf);for(let i=0;i<b.length;i+=0x8000)s+=String.fromCharCode.apply(null,b.subarray(i,i+0x8000));return btoa(s);}
  window.claude={use:async function(n){
    if(n!=='downloads')return null;
    return {save:async function(o){
      const blob=o.data,CH=1<<20;
      AndroidBridge.begin(o.filename,blob.type||'video/mp4');
      for(let p=0;p<blob.size;p+=CH){AndroidBridge.chunk(toB64(await blob.slice(p,p+CH).arrayBuffer()));}
      AndroidBridge.end();
    }};
  }};
})();
