package com.cubeland.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(0xFF2B2217.toInt())

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = WebChromeClient()
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("https://appassets.androidplatform.net/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finish() }
        })
    }

    private fun immersive() {
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) immersive() }
    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onDestroy() { web.destroy(); super.onDestroy() }

    /** Receives recorded videos from the page in chunks and saves them to Movies/Cubeland. */
    inner class Bridge {
        private var out: OutputStream? = null
        private var pending: android.net.Uri? = null

        @JavascriptInterface fun begin(name: String, mime: String) {
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "${System.currentTimeMillis()}_$name")
                        put(MediaStore.Video.Media.MIME_TYPE, mime)
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Cubeland")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    pending = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                    out = contentResolver.openOutputStream(pending!!)
                } else {
                    val d = getExternalFilesDir(Environment.DIRECTORY_MOVIES)!!.apply { mkdirs() }
                    out = FileOutputStream(File(d, "${System.currentTimeMillis()}_$name"))
                }
            } catch (e: Exception) { toast("Could not save video") }
        }
        @JavascriptInterface fun chunk(b64: String) { try { out?.write(Base64.decode(b64, Base64.DEFAULT)) } catch (_: Exception) {} }
        @JavascriptInterface fun end() {
            try {
                out?.close()
                pending?.let {
                    contentResolver.update(it, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                }
                toast("Video saved to Movies/Cubeland")
            } catch (_: Exception) { toast("Could not save video") }
            out = null; pending = null
        }
        private fun toast(m: String) = runOnUiThread { Toast.makeText(this@MainActivity, m, Toast.LENGTH_SHORT).show() }
    }
}
