# Cubeland – Android app

Open this folder in Android Studio (Koala or newer) and let Gradle sync. On first build it
downloads three.js and mp4-muxer into app/src/main/assets/libs so the game runs offline.
Then Run, or Build > Build APK(s). Debug APK: app/build/outputs/apk/debug/app-debug.apk

Notes
- Landscape, fullscreen, hardware-accelerated WebView; settings save via localStorage.
- Recorded videos/reels save to Movies/Cubeland through a small native bridge.
- The retro font loads from Google Fonts when online; offline it falls back to monospace.
- Back button exits the app.
